/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package upi.ac.cr.calculadora;

import java.util.Scanner;

/**
 *
 * @author Arianna Lèpiz G
 */
public class Calculadora {

    public static void main(String[] args) {
         Scanner Numero = new Scanner(System.in);
        
        while (true) {
            System.out.println("Opciones:");
            System.out.println("Ingrese '1' para sumar");
            System.out.println("Ingrese '2' para restar");
            System.out.println("Ingrese '3' para multiplicar");
            System.out.println("Ingrese '4' para dividir");
            System.out.println("Ingrese '5' para salir");
            
            System.out.print("Seleccione una opción: ");
            int opcion = Numero.nextInt();
            
            if (opcion == 5) {
                break;
            }
            
            if (opcion >= 1 && opcion <= 4) {
                System.out.print("Ingrese el primer número: ");
                double numero1 = Numero.nextDouble();
                System.out.print("Ingrese el segundo número: ");
                double numero2 = Numero.nextDouble();
                
                switch (opcion) {
                    case 1:
                        System.out.println("Resultado: " + suma(numero1, numero2));
                        break;
                    case 2:
                        System.out.println("Resultado: " + resta(numero1, numero2));
                        break;
                    case 3:
                        System.out.println("Resultado: " + multiplicacion(numero1, numero2));
                        break;
                    case 4:
                        double resultado = division(numero1, numero2);
                        if (Double.isNaN(resultado)) {
                            System.out.println("Error: División por cero");
                        } else {
                            System.out.println("Resultado: " + resultado);
                        }
                        break;
                }
            } else {
                System.out.println("Opción no válida");
            }
        }
    }
    
    public static double suma(double numero1, double numero2) {
        return numero1 + numero2;
    }
    
    public static double resta(double numero1, double numero2) {
        return numero1 - numero2;
    }
    
    public static double multiplicacion(double numero1, double numero2) {
        return numero1 * numero2;
    }
    
    public static double division(double numero1, double numero2) {
        if (numero2 == 0) {
            return Double.NaN; // Indica un valor que no es válido para la división por cero.
        } else {
            return numero1 / numero2;
        }
    }
    
}
